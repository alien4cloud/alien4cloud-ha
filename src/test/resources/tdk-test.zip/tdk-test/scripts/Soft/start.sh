#!/bin/bash -e
echo "I would like to see this in logs just before it fails !!!" >&2
exit 777