#!/bin/bash -e
echo "std output is in the place" >&1
echo "err output is in the place" >&2