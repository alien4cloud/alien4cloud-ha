#!/bin/bash -e

sudo service smbd restart
sudo service nmbd restart
