#!/bin/bash -e

sudo service smbd stop
sudo service nmbd stop
