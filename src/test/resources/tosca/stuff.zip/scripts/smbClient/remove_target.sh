#!/bin/bash -e

## unmount the samba share
sudo umount $MOUNT_POINT
