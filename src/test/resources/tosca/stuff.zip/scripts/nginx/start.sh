#!/bin/bash
sudo /etc/init.d/nginx reload
